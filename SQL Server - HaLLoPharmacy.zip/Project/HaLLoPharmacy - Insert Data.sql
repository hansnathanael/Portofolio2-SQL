USE HaLLoPharmacy
GO

INSERT INTO MsCustomer VALUES
('CU001', 'Nadia Rahmawati', 'nadia.rahmawati@hallo.com', '081920063304', 'Jl. Danau Terusnan 99', '1988-01-17', 'Female', 'bx3xpctf'),
('CU002', 'Kayun Firgantoro', 'kayun.firgantoro@hallo.com', '085801135188', 'Jl. Agung Karya VII Blok C/8', '1982-12-12', 'Male', 'dttoa87k'),
('CU003', 'Mahmud Mansur', 'mahmud.mansur@hallo.com', '081896090910', 'Jl. Pintu Air II 55', '1983-11-09', 'Male', '1qvm57ja'),
('CU004', 'Sarah Maryati', 'sarah.maryati@hallo.com', '085820756893', 'Jl. Krekot Jaya Blok I/10-11', '1983-06-16', 'Female', 'w4svpizo'),
('CU005', 'Pangeran Kurniawan', 'pangeran.kurniawan@hallo.com', '081912316859', 'Jl. Kwitang Raya 31 A', '1999-06-19', 'Male', '1qh959jx'),
('CU006', 'Febi Mayasari', 'febi.mayasari@hallo.com', '081810292041', 'Jl. RS Fatmawati 39', '1993-03-28', 'Female', 'u7e3arln'),
('CU007', 'Cahyo Pranowo', 'cahyo.pranowo@hallo.com', '089748256973', 'Jl. Kemang I 4B', '1995-11-13', 'Male', 'q83k38mf'),
('CU008', 'Kayla Oktaviani', 'kayla.oktaviani@hallo.com', '081732459322', 'Jl. KH Moch Mansyur Bl A-15/10-11', '1998-05-09', 'Female', '09yk3pry'),
('CU009', 'Diana Susanti', 'diana.susanti@hallo.com', '081486479931', 'Jl. Taman Sari Raya 56-GE', '1990-01-22', 'Female', 'cq5gd0wj'),
('CU010', 'Anita Lailasari', 'anita.lailasari@hallo.com', '087714124897', 'Jl. Melati Tugu VI 19', '1987-08-18', 'Female', 'gh3ghbvc'),
('CU011', 'Ibrahim Sihombing', 'ibrahim.sihombing@hallo.com', '089907321213', 'Jl. Kemang Timur V 18', '1997-10-11', 'Male', 'xj3ghj03'),
('CU012', 'Johan Maulana', 'johan.maulana@hallo.com', '082199734465', 'Jl. Taman Duta Mas Blok A-7/25', '1993-02-28', 'Male', 'rschqpk8'),
('CU013', 'Irfan Mandala', 'irfan.mandala@hallo.com', '082132084007', 'Jl. Buncit Raya 43', '1985-10-08', 'Male', '4unojpb8'),
('CU014', 'Clara Aryani', 'clara.aryani@hallo.com', '088281092274', 'Jl. Raya Hankam 33', '2000-12-20', 'Female', 'e06584lp'),
('CU015', 'Salsabila Nuraini', 'salsabila.nuraini@hallo.com', '087855620781', 'Jl. Nusa Indah IV 2', '1995-07-17', 'Female', 'rmglzh25')

INSERT INTO MsVendor VALUES
('VN001', 'UD Safitri Mardhiyah Tbk', 'jaryani@rahimah.com', '081281329234', 'Jl. Bara Tambar No. 416', '2002'),
('VN002', 'Perum Usamah', 'sirait.prasetya@yolanda.com', '083181329234', 'Jl. Diponegoro No. 375', '2001'),
('VN003', 'PD Hidayat Tbk', 'wacana.cahyadi@yahoo.com', '085276033945', 'Jl. Baladewa No. 94', '2003'),
('VN004', 'CV Yuliarti (Persero) Tbk', 'jaiman.simbolon@gmail.com', '081315119229', 'Jl. Gatot Subroto No. 940', '2001'),
('VN005', 'CV Hidayat Sudiati', 'cengkir.mansur@yahoo.com', '081164539233', 'Jl. Yos Sudarso No. 365', '2005'),
('VN006', 'Perum Sirait', 'latika29@irawan.com', '087731074557', 'Jl. Achmad No. 38', '2002'),
('VN007', 'PD Maheswara Tbk', 'orahimah@yahoo.com', '085132565734', 'Jl. Soekarno Hatta No. 680', '2001'),
('VN008', 'PT Yuniar Hakim', 'jprastuti.emin@yahoo.com', '089776564954', 'Jl. Kyai Gede No. 804', '2003'),
('VN009', 'UD Nurdiyanti Tbk', 'hassanah.upik@prasetyo.com', '085780254782', 'Jl. Kebangkitan Nasional No. 294', '2002'),
('VN010', 'PD Nasyiah Suryono', 'vivi.sitorus@andriani.com', '081369212334', 'Jl. Padang No. 747', '2002'),
('VN011', 'UD Hartati (Persero) Tbk', 'inababan@gmail.com', '085132257115', 'Jl. Lumban Tobing No. 646', '2002'),
('VN012', 'UD Hutagalung Tarihoran', 'jharsaya71@yahoo.com', '08118969480', 'Jl. Salatiga No. 649,', '2005'),
('VN013', 'PT Maryati', 'fiswahyudi@hartati.com', '089746511557', 'Jl. Yogyakarta No. 591', '2004'),
('VN014', 'Perum Utami Tbk', 'aris05@yahoo.com', '087729086631', 'Jl. Gading No. 385', '2005'),
('VN015', 'Perum Mangunsong Tbk', 'caket.wacana@puspita.com', '081215835930', 'Jl. Abdul Muis No. 106', '2004')

INSERT INTO MsEmployee VALUES
('EM001', 'Bahuwarna Winarno', 'bahuwarna.winarno@hallo.com', '081892837492', 'Jl. Puri Agung Ruko Puri Indah 30 Ground Floor', '1991-12-01', 'Male', '4500000'),
('EM002', 'Suci Puspasari', 'suci.puspasari@hallo.com', '087792836283', 'Jl. MH Thamrin 57 Permata Plaza 11th Floor', '1986-06-10', 'Female', '4700000'),
('EM003', 'Marsito Prasetya', 'marsito.prasetya@hallo.com', '085192739374', 'Jl. Ir H Juanda III/24 Batu Tulis', '1984-08-03', 'Male', '5000000'),
('EM004', 'Widya Lestari', 'widya.lestari@hallo.com', '081823463728', 'Jl. Tebet Timur Dalam III H 8', '1978-09-04', 'Female', '4600000'),
('EM005', 'Lasmanto Sihombing', 'lasmanto.sihombing@hallo.com', '0818219372638', 'Jl. Peta Barat 110 B', '1994-10-12', 'Male', '4600000'),
('EM006', 'Hamima Winarsih', 'hamima.winarsih@hallo.com', '081138592057', 'Jl. Tebet Timur Dalam Raya 91 A', '1990-07-14', 'Female', '4700000'),
('EM007', 'Reza Wahyudin', 'reza.wahyudin@hallo.com', '085128364827', 'Jl. Matraman Dlm II 6', '1979-06-01', 'Male', '4600000'),
('EM008', 'Genta Purwanti', 'genta.purwanti@hallo.com', '081110395759', 'Jl. Wijaya I 29', '1983-01-17', 'Male', '4500000'),
('EM009', 'Simon Prasetya', 'simon.prasetya@hallo.com', '087702939375', 'Jl. Biak 36 C', '1984-01-24', 'Male', '4500000'),
('EM010', 'Mala Wahyuni', 'mala.wahyuni@hallo.com', '083292970123', 'Jl. Teluk Betung 45 E', '1976-07-24', 'Female', '4600000'),
('EM011', 'Sabrina Wijayanti', 'sabrina.wijayanti@hallo.com', '082383920436', 'Jl. Dr Makaliwe I 7', '1979-01-20', 'Female', '5000000'),
('EM012', 'Tedi Tarihoran', 'tedi.tarihoran@hallo.com', '082372698325', 'Jl. Jend Sudirman Kav 36', '1975-11-08', 'Male', '4600000'),
('EM013', 'Endah Hartati', 'endah.hartati@hallo.com', '089593577283', 'Jl. Aipda KS Tubun IV 16', '1990-11-12', 'Female', '5000000'),
('EM014', 'Melinda Widiastuti', 'melinda.widiastuti@hallo.com', '083203926582', 'Jl. Pasar Minggu Raya 19', '1983-03-17', 'Female', '4600000'),
('EM015', 'Irwan Winarno', 'irwan.winarno@hallo.com', '089557382938', 'Jl. Mesjid Al Abror 7', '1995-10-20', 'Male', '4700000')

INSERT INTO MsMedicineCategory VALUES
('CT001', 'Antacid'),
('CT002', 'Paracetamol'),
('CT003', 'Antibiotic'),
('CT004', 'Cough Suppressants'),
('CT005', 'Diclofenac'),
('CT006', 'Suplement'),
('CT007', 'Dimenhydrinate'),
('CT008', 'Antiemetics'),
('CT009', 'Clotrimazole'),
('CT010', 'Biguanides'),
('CT011', 'Statins'),
('CT012', 'Benzodiazepines'),
('CT013', 'Immunosuppressives'),
('CT014', 'Sulfonamides'),
('CT015', 'Heparins')

INSERT INTO MsMedicine VALUES 
('MD001', 'CT001', 'Polysilane', '28000', 'Indigestion treatment', '200'),
('MD002', 'CT002', 'Panadol', '10500', 'Reduce fever and low to mild pain treatment', '280'),
('MD003', 'CT002', 'Tempra', '50500', 'Reduce fever and low to mild pain treatment', '190'),
('MD004', 'CT003', 'Cefadroxil', '8000', 'Infection treatment', '245'),
('MD005', 'CT004', 'Herbakof', '15000', 'Herbal cough treatment', '65'),
('MD006', 'CT005', 'Voltadex', '8500', 'Anti inflammatory medication', '120'),
('MD007', 'CT006', 'Fatigon', '69000', 'Boost stamina, energy and daily fit', '125'),
('MD008', 'CT007', 'Microlax', '20000', 'Constipation treatment', '100'),
('MD009', 'CT006', 'Hemaviton', '17500', 'Boost stamina, energy and daily fit', '140'),
('MD010', 'CT008', 'Antimo', '5200', 'Nausea and motion sickness treatment', '190'),
('MD011', 'CT009', 'Canesten', '25000', 'Fungal skin infection treatment', '165'),
('MD012', 'CT001', 'Promag', '23000', 'Indigestion treatment', '200'),
('MD013', 'CT010', 'Metformine', '48000', 'Type 2 diabetes treatment', '50'),
('MD014', 'CT004', 'Laserin', '6500', 'Herbal cough treatment', '80'),
('MD015', 'CT011', 'Simvastatin', '30500', 'Hypercholesterolemia and hypertriglyceridemia treatment', '45')