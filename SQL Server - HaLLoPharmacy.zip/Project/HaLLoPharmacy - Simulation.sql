USE HaLLoPharmacy
GO

CREATE TRIGGER tr_UpdateStock1
ON SalesTransactionDetail
AFTER INSERT
AS 
BEGIN
	UPDATE msm
	SET msm.MedicineStock = msm.MedicineStock - i.inserted_quantity
	FROM MsMedicine msm
	JOIN (
			SELECT i.MedicineID, SUM(i.SalesQTY) AS inserted_quantity
			FROM inserted i
			GROUP BY i.MedicineID
		) AS i
	ON msm.MedicineID = i.MedicineID
END
GO

CREATE TRIGGER tr_UpdateStock2
ON PurchaseTransactionDetail
AFTER INSERT
AS
BEGIN
	UPDATE msm
	SET msm.MedicineStock = msm.MedicineStock + i.inserted_quantity
	FROM MsMedicine msm
	JOIN (
			SELECT i.MedicineID, SUM(i.PurchaseQTY) AS inserted_quantity
			FROM inserted i
			GROUP BY i.MedicineID
		) AS i
	ON msm.MedicineID = i.MedicineID
END
GO

INSERT INTO SalesTransactionHeader VALUES
('SL001', 'EM005', 'CU013', '2018-05-31'),
('SL002', 'EM008', 'CU009', '2018-12-09'),
('SL003', 'EM001', 'CU015', '2019-04-05'),
('SL004', 'EM003', 'CU010', '2020-03-31'),
('SL005', 'EM002', 'CU008', '2020-07-10'),
('SL006', 'EM007', 'CU014', '2021-03-20'),
('SL007', 'EM004', 'CU012', '2021-06-14'),
('SL008', 'EM006', 'CU011', '2021-11-03'),
('SL009', 'EM010', 'CU002', '2018-01-20'),
('SL010', 'EM009', 'CU003', '2018-11-12'),
('SL011', 'EM015', 'CU006', '2019-07-06'),
('SL012', 'EM011', 'CU004', '2019-12-29'),
('SL013', 'EM013', 'CU001', '2020-05-11'),
('SL014', 'EM012', 'CU007', '2021-04-19'),
('SL015', 'EM014', 'CU005', '2021-08-01')
GO

INSERT INTO SalesTransactionDetail VALUES 
('SL001', 'MD002', 2),
('SL001', 'MD007', 3),
('SL002', 'MD004', 2),
('SL002', 'MD008', 1),
('SL002', 'MD011', 2),
('SL002', 'MD015', 3),
('SL003', 'MD001', 5),
('SL003', 'MD005', 4),
('SL003', 'MD004', 2),
('SL004', 'MD013', 4),
('SL005', 'MD008', 1),
('SL005', 'MD009', 2),
('SL006', 'MD011', 6),
('SL006', 'MD013', 3),
('SL006', 'MD014', 5),
('SL006', 'MD015', 2),
('SL007', 'MD015', 3),
('SL008', 'MD003', 4),
('SL008', 'MD006', 5),
('SL008', 'MD014', 1),
('SL009', 'MD010', 5),
('SL009', 'MD012', 1),
('SL010', 'MD001', 2),
('SL011', 'MD002', 4),
('SL011', 'MD008', 2),
('SL011', 'MD009', 3),
('SL012', 'MD011', 3),
('SL012', 'MD013', 2),
('SL013', 'MD011', 2),
('SL014', 'MD006', 2),
('SL014', 'MD007', 2),
('SL014', 'MD014', 7),
('SL015', 'MD005', 1),
('SL015', 'MD014', 3),
('SL015', 'MD015', 1)
GO

INSERT INTO PurchaseTransactionHeader VALUES
('PC001', 'EM008', 'VN013', '2018-04-11'),
('PC002', 'EM006', 'VN006', '2018-09-13'),
('PC003', 'EM003', 'VN007', '2018-12-02'),
('PC004', 'EM012', 'VN013', '2018-12-08'),
('PC005', 'EM008', 'VN004', '2019-01-03'),
('PC006', 'EM014', 'VN007', '2019-05-22'),
('PC007', 'EM011', 'VN005', '2019-06-16'),
('PC008', 'EM012', 'VN010', '2019-09-30'),
('PC009', 'EM007', 'VN003', '2020-02-21'),
('PC010', 'EM001', 'VN008', '2020-05-17'),
('PC011', 'EM015', 'VN011', '2020-10-22'),
('PC012', 'EM013', 'VN001', '2020-12-02'),
('PC013', 'EM005', 'VN012', '2021-01-18'),
('PC014', 'EM014', 'VN002', '2021-06-27'),
('PC015', 'EM011', 'VN005', '2021-09-04'),
('PC016', 'EM006', 'VN006', '2021-11-25')
GO

INSERT INTO PurchaseTransactionDetail VALUES 
('PC001', 'MD012', 18),
('PC001', 'MD011', 32),
('PC001', 'MD015', 24),
('PC001', 'MD013', 27),
('PC001', 'MD003', 19),
('PC002', 'MD006', 21),
('PC002', 'MD010', 25),
('PC002', 'MD009', 11),
('PC002', 'MD002', 13),
('PC003', 'MD003', 21),
('PC004', 'MD001', 13),
('PC004', 'MD006', 37),
('PC004', 'MD004', 50),
('PC004', 'MD005', 33),
('PC005', 'MD013', 11),
('PC005', 'MD014', 10),
('PC006', 'MD007', 29),
('PC007', 'MD012', 10),
('PC008', 'MD003', 26),
('PC008', 'MD002', 13),
('PC008', 'MD014', 50),
('PC009', 'MD011', 22),
('PC009', 'MD005', 12),
('PC010', 'MD007', 20),
('PC010', 'MD003', 10),
('PC010', 'MD012', 13),
('PC011', 'MD009', 23),
('PC012', 'MD001', 14),
('PC012', 'MD003', 27),
('PC013', 'MD012', 11),
('PC013', 'MD015', 32),
('PC014', 'MD004', 11),
('PC015', 'MD008', 29),
('PC015', 'MD010', 10),
('PC016', 'MD014', 23)