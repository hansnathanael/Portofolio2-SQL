-- 1
SELECT
	[CustomerID] = c.CustomerID,
	[Customer Name] = CustomerName,
	[Transaction Date] = CONVERT(VARCHAR, SalesTransactionDate, 107),
	[Medicine Bought] = SUM(SalesQTY)
FROM
	SalesTransactionHeader sh
	JOIN SalesTransactionDetail sd
	ON sd.SalesTransactionID = sh.SalesTransactionID
	JOIN MsCustomer c
	ON c.CustomerID = sh.CustomerID
WHERE
	CustomerGender = 'Female' AND
	DAY(SalesTransactionDate) BETWEEN 20 AND 30
GROUP BY
	c.CustomerID,
	CustomerName,
	SalesTransactionDate

-- 2
SELECT
	[EmployeeNumber] = RIGHT(e.EmployeeID, 3),
	[Employee Name] = EmployeeName,
	[Customer Served] = CAST(COUNT(c.CustomerID) AS VARCHAR) + ' customer(s)'
FROM
	MsEmployee e
	JOIN SalesTransactionHeader sh
	ON sh.EmployeeID = e.EmployeeID
	JOIN MsCustomer c
	ON c.CustomerID = sh.CustomerID
WHERE
	EmployeeName LIKE '%b%' AND
	EmployeeGender = 'Female'
GROUP BY
	e.EmployeeID,
	EmployeeName

-- 3
SELECT 
	[Customer ID] = c.CustomerID,
	[Customer Name] = c.CustomerName,
	[Date of Birth] = CONVERT(VARCHAR, c.CustomerDOB, 106),
	[Transaction Count] = COUNT(sh.SalesTransactionID),
	[Total Purchase] = SUM(sd.SalesQTY)
FROM
	SalesTransactionHeader sh
	JOIN SalesTransactionDetail sd
	ON sd.SalesTransactionID = sh.SalesTransactionID
	JOIN MsCustomer c
	ON c.CustomerID = sh.CustomerID
WHERE
	sh.EmployeeID LIKE 'EM[0][0][4, 6, 8]' AND
	MONTH(sh.SalesTransactionDate) BETWEEN 1 AND 6
GROUP BY
	c.CustomerID,
	c.CustomerName,
	c.CustomerDOB

-- 4
SELECT
	[Employee ID] = e.EmployeeID,
	[Employee Name] = e.EmployeeName,
	[Local Phone Number] = REPLACE(e.EmployeePhoneNumber, '08', '62'),
	[Transaction Done] = COUNT(ph.PurchaseTransactionID),
	[Total Medicine Bought] = CAST(SUM(pd.PurchaseQTY) AS VARCHAR) + ' item(s)'
FROM
	MsEmployee e
	JOIN PurchaseTransactionHeader ph
	ON ph.EmployeeID = e.EmployeeID
	JOIN PurchaseTransactionDetail pd
	ON pd.PurchaseTransactionID = ph.PurchaseTransactionID
	JOIN MsVendor v
	ON v.VendorID = ph.VendorID
WHERE
	DAY(ph.PurchaseTransactionDate) BETWEEN 10 AND 20 AND
	v.VendorEstablishedYear > 2000
Group BY
	e.EmployeeID,
	e.EmployeeName,
	e.EmployeePhoneNumber

-- 5
SELECT
	[Numeric Medicine ID] = RIGHT(m.MedicineID, 3),
	[Medicine Name] = UPPER(MedicineName),
	[Category Name] = MedicineCategoryName,
	[Price] = CONCAT('Rp. ', MedicinePrice),
	[Medicine Stock] = MedicineStock
FROM
	MsMedicine m
	JOIN MsMedicineCategory mc
	ON mc.MedicineCategoryID = m.MedicineCategoryID
	JOIN SalesTransactionDetail std
	ON std.MedicineID = m.MedicineID,
	(
		SELECT 
			[Average] = AVG(SalesQTY)
		FROM
			SalesTransactionDetail
	) AS sub
WHERE
	MedicinePrice > 50000 AND
	MedicineStock < sub.Average
GROUP BY
	m.MedicineID,
	MedicineName,
	MedicineCategoryName,
	MedicinePrice,
	MedicineStock

-- 6
SELECT
	[Employee Code] = REPLACE(e.EmployeeID, 'EM', 'EMPLOYEE'),
	[Employee Name] = EmployeeName,
	[Transaction Date] = CONVERT(VARCHAR,SalesTransactionDate, 101),
	[Medicine Name] = m.MedicineName,
	[Quantity] = SalesQty
FROM
	MsEmployee e
	JOIN SalesTransactionHeader sth
	ON e.EmployeeID = sth.EmployeeID
	JOIN SalesTransactionDetail std
	ON sth.SalesTransactionID = std.SalesTransactionID
	JOIN MsMedicine m
	ON m.MedicineID = std.MedicineID,
	(
		SELECT 
			[Average] = AVG(EmployeeSalary)
		FROM
			MsEmployee
	) AS sub
WHERE 
	DAY(sth.SalesTransactionDate) LIKE 2 AND
	EmployeeSalary < sub.Average
GROUP BY
	e.EmployeeID,
	EmployeeName,
	SalesTransactionDate,
	MedicineName,
	SalesQty

-- 7
SELECT
	[Customer ID] = msc.CustomerID,
	[Customer Name] = CustomerName,
	[Local Customer Phone] = REPLACE(CustomerPhoneNumber, '08', '62'),
	[Date of Birth] = CONVERT(VARCHAR, CustomerDOB, 107),
	[Medicine Bought] = CAST(SUM(SalesQTY) AS VARCHAR) + ' item(s)'
FROM 
	SalesTransactionHeader sth
	JOIN MsCustomer msc
	ON sth.CustomerID = msc.CustomerID
	JOIN SalesTransactionDetail std
	ON std.SalesTransactionID = sth.SalesTransactionID,
	(
		SELECT 
			[Average] = AVG(SalesQTY)
		FROM 
			SalesTransactionDetail
	) AS sub
WHERE
	CustomerGender = 'Female'
GROUP BY 
	std.SalesTransactionID,
	msc.CustomerID,
	CustomerName,
	CustomerPhoneNumber,
	CustomerDOB,
	sub.Average
HAVING
	SUM(SalesQTY) > sub.Average
ORDER BY
	msc.CustomerID

-- 8
SELECT
	[Employee ID] = mse.EmployeeID,
	[Employee Name] = LEFT(EmployeeName, CHARINDEX(' ', EmployeeName) - 1),
	[Salary] = 'Rp. ' + CAST(EmployeeSalary AS VARCHAR),
	[Date of Birth] = CONVERT(VARCHAR, EmployeeDOB, 107),
	[Transaction Served] = COUNT(SalesTransactionID)
FROM
	SalesTransactionHeader sth
	JOIN MsEmployee mse
	ON sth.EmployeeID = mse.EmployeeID,
	(
		SELECT 
			[Serving] = COUNT(*)
		FROM
			SalesTransactionHeader
	) AS sub
WHERE
	EmployeeName LIKE '% %'
GROUP BY
	SalesTransactionID,
	mse.EmployeeID,
	EmployeeName,
	EmployeeSalary,
	EmployeeDOB
HAVING
	COUNT(SalesTransactionID) > AVG(sub.Serving)
ORDER BY 
	mse.EmployeeID

-- 9
CREATE VIEW VendorMaximumAverageQuantityViewer AS
SELECT
	[Vendor ID] = msv.VendorID,
	[Vendor Name] = VendorName,
	[Average Supplied Quantity] = CAST(AVG(PurchaseQTY) AS VARCHAR) + ' item(s)',
	[Maximum Supplied Quantity] = CAST(MAX(PurchaseQTY) AS VARCHAR) + ' item(s)'
FROM
	PurchaseTransactionHeader pth
	JOIN PurchaseTransactionDetail ptd
	ON ptd.PurchaseTransactionID = pth.PurchaseTransactionID
	JOIN MsVendor msv
	ON pth.VendorID = msv.VendorID
WHERE
	VendorName LIKE '%a%'
GROUP BY
	msv.VendorID,
	VendorName
HAVING
	MAX(PurchaseQTY) > 5

SELECT * FROM VendorMaximumAverageQuantityViewer

-- 10
CREATE VIEW VendorSupplyViewer AS
SELECT
	[Vendor Number] = RIGHT(msv.VendorID, 3),
	[Vendor Name] = VendorName,
	[Vendor Address] = VendorAddress,
	[Total Supplied Value] = 'Rp. ' + CAST(SUM(MedicinePrice * PurchaseQTY) AS VARCHAR),
	[Medicine Type Supplied] = CAST(COUNT(ptd.MedicineID) AS VARCHAR) + ' medicine(s)'
FROM
	PurchaseTransactionHeader pth
	JOIN PurchaseTransactionDetail ptd
	ON ptd.PurchaseTransactionID = pth.PurchaseTransactionID
	JOIN MsVendor msv
	ON pth.VendorID = msv.VendorID
	JOIN MsMedicine msm
	ON ptd.MedicineID = msm.MedicineID
GROUP BY
	msv.VendorID,
	VendorName,
	VendorAddress
HAVING
	SUM(MedicinePrice * PurchaseQTY) > 150000 AND
	COUNT(ptd.MedicineID) > 2

SELECT * FROM VendorSupplyViewer